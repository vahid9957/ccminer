<?php
$terminalId = "aaa";
$userName = "bbb";
$userPassword = "ccc";
$SystemURL = "WHMCS_URL";
?>
