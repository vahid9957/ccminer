# whmcs-bankmellat-gateway
مازول بانک ملت برای whmcs


بعد از آپلود باید فایل : <br>
gateways/Mellat/Mellat/config.php<br>
ویرایش شود و اطلاعات دریافتی از به پرداخت در اون وارد بشه

این ماژول در تاریخ ۲۱ آذر ۹۶ تست شده و بدون مشکل کار میکنه.

https://mihanservice.com/
