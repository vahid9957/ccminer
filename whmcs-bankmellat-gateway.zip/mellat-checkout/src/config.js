export default {
  apiUrl: 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl',
  terminalId: '',
  username: '',
  password: '',
  timeout: 10000,
};
