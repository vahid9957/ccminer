﻿namespace Adin.BankPayment.Connector.Enum
{
    public enum BankCodeEnum
    {
        Default = 0,
        Saman = 1,
        Parsian = 2,
        Mellat = 3,
        Efarda = 4
    }
}