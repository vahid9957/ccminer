﻿namespace Adin.BankPayment.Connector.Enum
{
    public enum PriceUnitEnum
    {
        Default = 0,
        Rial = 1,
        Toman = 2,
        Dollar = 3
    }
}