﻿namespace Adin.BankPayment.Domain.Cache
{
    public static class ConnectionStringGetter
    {
        public static string ConStr { get; set; }
    }
}