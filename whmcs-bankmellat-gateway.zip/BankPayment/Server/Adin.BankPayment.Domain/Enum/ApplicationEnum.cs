﻿namespace Adin.BankPayment.Domain.Enum
{
    public enum ApplicationEnum
    {
        Normal = 0,
        Blocked = 1
    }
}