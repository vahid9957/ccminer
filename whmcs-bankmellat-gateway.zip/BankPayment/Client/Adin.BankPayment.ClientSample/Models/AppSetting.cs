﻿namespace Adin.BankPayment.ClientSample.Models
{
    public static class AppSetting
    {
        public static string PaymentKey { get; set; }
    }
}