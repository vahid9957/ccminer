# mellat_bank_node
درگاه پرداخت بانک ملت node.js

## Getting Started
this project build on top of Express.js for development and testing mellat bank script.

### how to use
use ```npm install``` to install dependecis. open ```BankMellat.js``` and set your terminalId, userName, password and callbackUrl according to your account. then run the app using ``` node server.js```.

## Acknowledgments
قبل از اینکه بخواهید درگاه را تست کنید ابتدا باید در به پرداخت  بانک ملت فروشگاه خود را ثبت کرده و دارای اکانت باشید

## Contributing
خوشحال میشم شما هم در بهتر کردن این اسکریپت مشارکت کنید

## Authors

* **milad ranjbar**  - [MiladRanjbar](https://github.com/miladr0)
