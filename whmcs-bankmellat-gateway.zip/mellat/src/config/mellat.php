<?php
return [
    'terminalId'=>'',
    'username'=>'',
    'password'=>'',
    'callBackUrl'=>'',
    'convertToRial'=>true
];
