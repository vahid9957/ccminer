<?php
/*
Plugin Name: درگاه پرداخت بانک ملت افزونه ووکامرس
Version: 4.0.1
Description:  درگاه پرداخت بانک ملت برای افزونه ووکامرس
Plugin URI: http://woocommerce.ir/
Author: ووکامرس فارسی
Author URI: http://woocommerce.ir/
*/
include_once("class-wc-gateway-bankmellat.php");
//By HANNANStd in PersianScript.ir ==> woocommerce.ir